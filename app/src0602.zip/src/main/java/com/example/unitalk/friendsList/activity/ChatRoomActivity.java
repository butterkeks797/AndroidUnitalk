package com.example.unitalk.friendsList.activity;

import android.support.v7.app.AppCompatActivity;

public class ChatRoomActivity extends AppCompatActivity {
}

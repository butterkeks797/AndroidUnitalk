package com.example.unitalk.friendsList;

public class GetDataType {
    private int iv_portrait;
    private String name;
    private String signature;
    public int getIv_portrait() {
        return iv_portrait;
    }
    public void setIv_portrait(int iv_portrait) {
        this.iv_portrait = iv_portrait;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getSignature() {
        return signature;
    }
    public void setSignature(String signature) {
        this.signature = signature;
    }

}
package com.example.unitalk.partnerMatch.activity;

import android.support.v7.app.AppCompatActivity;

public class PartnerMatchActivity extends AppCompatActivity {
}
